# Flipkart Clone Project

This is a clone of the Flipkart website created using HTML and CSS. 

The project is still in progress and JavaScript will be added later.

## [Click Here to Open](https://amankumarsinhagithub.github.io/Flipkart-Clone/)

## Note : 
If you are opening the site in mobile phone, Please open in Desktop Mode

## Preview Images:

![preview-img](https://github.com/AmanKumarSinhaGitHub/Flipkart-Clone/assets/65329366/7f7137a9-df36-45eb-a39b-8ff6efd64d7c)


## Contributing

Contributions are welcome! Please feel free to submit a pull request.
